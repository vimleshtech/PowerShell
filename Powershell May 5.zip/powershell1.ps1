﻿
# declare variable or data

##example  1
$n =1000  # assign data on variable 
Write-Host $n  # show result 


##example  2
$name = 'nitin'
$name 


## data type 

# number : a =100
# str/alpha  numeric : a ='shsjg s1133'
# date :   a ='10/01/1990' or "10/01/1990"
# boolean : a = true 


$sales = 22333444 # here $sales is variable , and 22333444 is data/value 
# variable is temp. memory 


#input and output 

$n = Read-Host "enter name "  # iput
Write-Host "your name is $n"



## condition  : is decision making statement 
$a =111
$b =111088


if($a -gt $b )
{ ## true / if match

    Write-Host "a is greater number"
}
else
{ ## false / if not match 

    Write-Host "b is greater number"
}



#### loop  
## while loop
$i  =1  # start / init 

while ($i -le 10)  # condition 
{

    Write-Host "data = $i "
    $i++ # or $i = $i+1     # increment or step 


}


# print in reverse order 
$i  =20  # start / init 

while ($i -ge 1)  # condition 
{

    Write-Host "data = $i "
    $i-- # or $i = $i-1     # decrement or step 


}


# print table of 4 

$i  =1  # start / init 

while ($i -le 10)  # condition 
{
    $o = $i *4
    Write-Host "data =  $o "
    $i++ # or $i = $i+1     # increment or step 


}



## for 
for($i=1; $i -le 10; $i++)
{

    Write-Host ($i *5)
}


#### array : collection of data
$a = 10  # scalar variable / single value 

$d = @(10,222,11,22,22,222,2) # array: collection of values 

#print 2nd element from array 
Write-Host $d[1] # here 1 is index of array , array index stars from 0 position 







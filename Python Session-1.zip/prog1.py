a = 10 # here a is variable/temp. memory where data can be stored , 10 is value

print(a)

print('value of a = ',a)
print("value of a = ",a)

#####################
a =1
print(type(a))

a =12.333
print(type(a))

a ='1'
print(type(a))


b =True
print(type(b))


b =['aaa',2,3,21,True]
print(type(b))



b =('aaa',2,3,21,True)
print(type(b))


b ={1:'one',2:'two'}
print(type(b))











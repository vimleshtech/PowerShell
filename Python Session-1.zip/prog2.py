hs =66
es =39
cs =43
ms                  =98


total = hs+es+cs+ms
avg = total/4



print('Total score = ',total)
print('Pect  = ',avg)


#grade
if avg > 80:
     print('***** grade details *****')
     print('Grade A')
elif avg > 70:
    print('Grade B')
elif avg>60:
    print('Grade C')
else:
    print('Grade D')


###
a =22
b  =333
c =22

#nested 
if a>b:
    if a>c:
        print('a is gt')
    else:
        print('b is gt')
else:

    if b>c:
        print('b is gt')
    else:
        print('c is gt')

#
if a>b and a>c:
    print('a is gt')
elif b>a and b>c:
    print('b is gt')
else:
    print('c is gt')


    

    

    


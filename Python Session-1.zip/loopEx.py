'''
A3
A4
A7
B8
B9
B10
'''


i =1 # init
while i<=10:                    #condition 

    print(i)
    i = i+1   # incrementer


#print in reverse
i =6
while i>0:
    print(i)
    i=i-1
    

###
for d in range(1,11,2):  # default incrementer is 1
    print(d)

    
